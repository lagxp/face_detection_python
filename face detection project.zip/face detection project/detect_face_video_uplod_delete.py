import sys
import os
import cv2
import requests
from PyQt5.QtCore import Qt, QDateTime
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QLabel, QFileDialog, QMessageBox

class ImageViewer(QWidget):
    def __init__(self, image_path, temp_folder):
        super().__init__()

        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)

        self.upload_button = QPushButton('Upload', self)
        self.upload_button.clicked.connect(lambda: self.upload_image(temp_folder))

        self.delete_button = QPushButton('Delete', self)
        self.delete_button.clicked.connect(lambda: self.delete_image(temp_folder))

        self.temp_folder = temp_folder  # Reference to the "temp" folder
        self.image_path = image_path  # Store the image path for deletion

        self.setup_ui(image_path)

    def setup_ui(self, image_path):
        layout = QVBoxLayout()
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print(f"Failed to load image from {image_path}")
        else:
            self.image_label.setPixmap(pixmap)
            layout.addWidget(self.image_label)
            layout.addWidget(self.upload_button)
            layout.addWidget(self.delete_button)  # Add the Delete button
            self.setLayout(layout)
            self.setWindowTitle('Image Viewer')

    def upload_image(self, temp_folder):
        if not temp_folder:
            print("Temp folder is not specified.")
            return

        # Save the current image to the temp folder
        timestamp = QDateTime.currentDateTime().toString("yyyyMMddHHmmss")
        image_path = os.path.join(temp_folder, f'uploaded_image_{timestamp}.png')

        current_pixmap = self.image_label.pixmap()
        current_pixmap.save(image_path)
        print(f"Image saved at: {image_path}")

        # Display a success message or handle further actions if needed
        QMessageBox.information(self, "Upload Successful", f"Image saved at: {image_path}")

    def delete_image(self, temp_folder):
        reply = QMessageBox.question(self, 'Delete Image', 'Are you sure you want to delete this image?',
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            # Delete the image file
            os.remove(self.image_path)
            print(f"Image deleted: {self.image_path}")

            # Delete the image from the server
            delete_url = 'https://example.com/delete'  # Replace with your server's delete API endpoint
            response = requests.post(delete_url, data={'image_path': self.image_path})
            print(f"Image deleted from server. Server response: {response.text}")

            # Close the image viewer widget
            self.close()


class CameraWindow(QWidget):
    def __init__(self, main_window):
        super().__init__()

        self.main_window = main_window
        self.camera_label = QLabel(self)
        self.capture_button = QPushButton('Capture')
        self.close_button = QPushButton('Close Camera')

        self.face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(self.camera_label)
        layout.addWidget(self.capture_button)
        layout.addWidget(self.close_button)
        self.setLayout(layout)
        self.setWindowTitle('Camera View')

        self.capture_button.clicked.connect(self.capture_image)
        self.close_button.clicked.connect(self.close_camera)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            self.capture_image()

    def show_frame(self, frame):
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Detect faces
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.1, 4)

        # Draw rectangles around faces
        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)

        h, w, ch = img.shape
        bytes_per_line = ch * w
        q_image = QImage(img.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(q_image)
        self.camera_label.setPixmap(pixmap)
        self.show()

    def capture_image(self):
        if hasattr(self, 'current_frame'):
            # Detect faces
            gray = cv2.cvtColor(self.current_frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 4)

            if len(faces) > 0:
                if len(faces) > 1:
                    # Multiple faces detected, show a pop-up message
                    self.show_multiple_faces_message()
                else:
                    # Create a temporary folder if it doesn't exist
                    temp_folder = 'temp'
                    os.makedirs(temp_folder, exist_ok=True)

                    # Generate a unique filename using timestamp
                    timestamp = QDateTime.currentDateTime().toString("yyyyMMddHHmmss")
                    image_path = os.path.join(temp_folder, f'captured_image_{timestamp}.png')

                    # Save the captured image to the temporary folder without converting color format
                    cv2.imwrite(image_path, self.current_frame)
                    print(f"Image captured and saved at: {image_path}")

                    # Create an instance of ImageViewer and pass the temp folder
                    viewer = ImageViewer(image_path, temp_folder)
                    viewer.show()

                    # Simulate uploading the captured image to a server
                    upload_url = 'https://example.com/upload'
                    files = {'file': open(image_path, 'rb')}
                    response = requests.post(upload_url, files=files)
                    print(f"Captured image uploaded. Server response: {response.text}")
            else:
                # No faces detected, show a pop-up message
                self.show_no_face_message()

    def show_multiple_faces_message(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText("Multiple faces detected. Please capture an image with only one face.")
        msg.setWindowTitle("Capture Error")
        msg.exec_()

    def show_no_face_message(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText("No face detected.")
        msg.setWindowTitle("Capture Error")
        msg.exec_()

    def close_camera(self):
        self.hide()
        self.main_window.show()



class CameraBrowserApp(QWidget):
    def __init__(self):
        super().__init__()

        self.camera_button = QPushButton('Camera')
        self.browser_button = QPushButton('Browser')

        self.camera_window = CameraWindow(self)

        self.browser_view = QLabel(self)
        self.selected_image_widget = None

        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(self.camera_button)
        layout.addWidget(self.browser_button)

        self.camera_button.clicked.connect(self.show_camera)
        self.browser_button.clicked.connect(self.browse_image)

        self.setLayout(layout)
        self.setWindowTitle('Camera & Browser App')

    def show_camera(self):
        self.camera_window.show()
        cap = cv2.VideoCapture(0)
        while self.camera_window.isVisible():
            ret, frame = cap.read()
            if ret:
                self.camera_window.show_frame(frame)
                self.camera_window.current_frame = frame  # Store the current frame for capturing
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()

    def browse_image(self):
        options = QFileDialog.Options()
        options |= QFileDialog.ReadOnly
        image_path, _ = QFileDialog.getOpenFileName(self, "Select Image", "", "Images (*.png *.jpg *.jpeg *.bmp *.gif)", options=options)

        if image_path:
            self.show_selected_image(image_path)

    def show_selected_image(self, image_path):
        # Show the selected image in the ImageViewer widget
        self.selected_image_widget = ImageViewer(image_path, 'temp')
        self.selected_image_widget.show()

        # Simulate uploading the selected image to a server
        upload_url = 'https://example.com/upload'
        files = {'file': open(image_path, 'rb')}
        response = requests.post(upload_url, files=files)
        print(f"Selected image uploaded. Server response: {response.text}")

    def delete_selected_image(self):
        if self.selected_image_widget:
            # Delete the image from the server
            delete_url = 'https://example.com/delete'  # Replace with your server's delete API endpoint
            response = requests.post(delete_url, data={'image_path': self.selected_image_widget.image_path})
            print(f"Image deleted from server. Server response: {response.text}")

            # Close the ImageViewer widget
            self.selected_image_widget.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = CameraBrowserApp()
    window.show()
    sys.exit(app.exec_())
